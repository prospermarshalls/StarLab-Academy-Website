<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, minimum-scale=1.0"
    />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="shortcut icon" href="./svg/android-chrome-192x192.png" type="image/x-icon">
    <title>About | Starlab</title>
    <script
      id="www-widgetapi-script"
      src="https://s.ytimg.com/yts/jsbin/www-widgetapi-vflS50iB-/www-widgetapi.js"
      async=""
    ></script>
    <script src="https://www.youtube.com/player_api"></script>
    <link rel="stylesheet preload" as="style" href="css/preload.min.css" />
    <link rel="stylesheet preload" as="style" href="css/icomoon.css" />
    <link rel="stylesheet preload" as="style" href="css/libs.min.css" />
    <link rel="stylesheet" href="./css/about.min.css" />
  </head>
  <body>
    <?php include './header.php'; ?> 
    <!-- about content start -->
    <main>
      <!-- features section start -->
      <div class="features">
        <div class="container">
          <ul class="features_list d-md-flex flex-wrap" >
            <li style="margin-bottom:40px;"
              class="features_list-item col-md-6 col-xl-4"
              data-order="1"
              data-aos="fade-up"
            >
              <div class="card">
                <div class="content">
                  <div class="card_media">
                    <i class="icon-user-graduate-solid icon"></i>
                  </div>
                  <div class="card_main">
                    <h5 class="card_main-title">Get a certificate</h5>
                    <p class="card_main-text">
                      Access tour certificate anytime, anywhere, with both
                      digital and high-quality formats.
                    </p>
                  </div>
                </div>
              </div>
            </li>
            <li style="margin-bottom:40px;"
              class="features_list-item col-md-6 col-xl-4"
              data-order="2"
              data-aos="fade-up"
            >
              <div class="card">
                <div class="content">
                  <div class="card_media">
                    <i class="icon-globe-solid icon"></i>
                  </div>
                  <div class="card_main">
                    <h5 class="card_main-title">All over the globe</h5>
                    <p class="card_main-text">
                      Join a global community of learners at StarLab Academy,
                      explore diverse educational resources and connect with
                      peers worldwide.
                    </p>
                  </div>
                </div>
              </div>
            </li>
            <li style="margin-bottom:40px;"
              class="features_list-item col-md-6 col-xl-4"
              data-order="3"
              data-aos="fade-up"
            >
              <div class="card">
                <div class="content">
                  <div class="card_media">
                    <i class="icon-headset-solid icon"></i>
                  </div>
                  <div class="card_main">
                    <h5 class="card_main-title">Live online lectures</h5>
                    <p class="card_main-text">
                      Join live online lectures by industry experts. Interactive
                      learning, Q&A sessions, personalized experiences. Latest
                      trends & networking opportunities.
                    </p>
                  </div>
                </div>
              </div>
            </li>
            <li style="margin-bottom:40px;"
              class="features_list-item col-md-6 col-xl-4"
              data-order="4"
              data-aos="fade-up"
            >
              <div class="card">
                <div class="content">
                  <div class="card_media">
                    <i class="icon-book-solid icon"></i>
                  </div>
                  <div class="card_main">
                    <h5 class="card_main-title">Educational materials</h5>
                    <p class="card_main-text">
                      Discover high-quality educational materials, explore
                      curriculum-aligned resources, and professional development
                      materials.
                    </p>
                  </div>
                </div>
              </div>
            </li>
            <li style="margin-bottom:40px;"
              class="features_list-item col-md-6 col-xl-4"
              data-order="5"
              data-aos="fade-up"
            >
              <div class="card">
                <div class="content">
                  <div class="card_media">
                    <i class="icon-gem-solid icon"></i>
                  </div>
                  <div class="card_main">
                    <h5 class="card_main-title">Professional teachers</h5>
                    <p class="card_main-text">
                      Professional teachers, certified and passionate about
                      education. Personalized learning, subject matter expertise
                      and supportive environments.
                    </p>
                  </div>
                </div>
              </div>
            </li>
            <li style="margin-bottom:40px;"
              class="features_list-item col-md-6 col-xl-4"
              data-order="6"
              data-aos="fade-up"
            >
              <div class="card">
                <div class="content">
                  <div class="card_media">
                    <i class="icon-universal-access-solid icon"></i>
                  </div>
                  <div class="card_main">
                    <h5 class="card_main-title">Accessibility programs</h5>
                    <p class="card_main-text">
                      Accessible education for all. Complaint platform, closed
                      captions & compatibility.
                    </p>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <!-- features section end -->
      <!-- info blocks section start -->
      <section class="infoblock d-flex flex-column flex-lg-row flex-md-wrap">
        <div
          class="infoblock_block col-lg-6 d-flex flex-column justify-content-center align-items-center"
          data-order="1"
        >
          <div class="content">
            <h2 class="infoblock_block-header">
              Education – Your Door To The Future
            </h2>
            <p class="infoblock_block-text">
              The best educational programs and opportunities for fast and
              effective learning. New professions, new opportunities and ways of
              working. You can learn more
            </p>
          </div>
        </div>
        <div class="infoblock_block col-lg-6" data-order="2">
          <div class="cover">
            <div class="cover_media">
              <picture>
                <source
                  data-srcset="./img/images.jpeg"
                  srcset="./img/images.jpeg"
                />
                <img
                  class="lazy"
                  data-src="./img/images.jpeg"
                  src="./img/images.jpeg"
                  alt="media"
                />
              </picture>
            </div>
            <a class="cover_play" href="#">
              <lottie-player
                src="lottie/play.json"
                background="transparent"
                speed=".5"
                style="width: 100%; height: 100%"
                loop
                autoplay
              ></lottie-player>
            </a>
            <span class="cover_duration">01:06</span>
          </div>
          <iframe
            src="https://www.youtube.com/embed/ulbAQvhKbME"
            title="YouTube video player"
            allowfullscreen
          ></iframe>
        </div>
        <div class="infoblock_block col-lg-6" data-order="3">
          <div class="parallax">
            <div class="img">
              <picture>
                <source
                  data-srcset="./img/events.jpeg"
                  srcset="./img/events.jpeg"
                />
                <img
                  class="lazy"
                  data-src="./img/events.jpeg"
                  src="./img/events.jpeg"
                  alt="media"
                />
              </picture>
            </div>
          </div>
        </div>
        <div
          class="infoblock_block col-lg-6 infoblock_block--sale d-flex flex-column justify-content-center align-items-center"
          data-order="4"
        >
          <div
            class="content d-flex flex-column flex-sm-row align-items-center align-items-sm-start"
          >
            <span class="content_percent">50%</span>
            <div
              class="content_text d-flex flex-column align-items-center align-items-xl-start"
            >
              <h3 class="title">
                <span class="percent">50%</span> Season sale
              </h3>
              <p class="text">
                Unlimited access to educational materials<span class="text_cut"
                  >and lectures</span
                >
              </p>
            </div>
          </div>
          <form
            class="form d-flex flex-column flex-sm-row"
            action="#"
            method="POST"
            data-type="subscription"
          >
            <input
              class="field required"
              type="text"
              data-type="email"
              placeholder="Subscribe by e-mail"
            />
            <button class="btn btn--gradient" type="submit">
              <span class="text">Get Started Now</span>
            </button>
          </form>
        </div>
      </section>
      <!-- info blocks section end -->
      <!-- reviews section start -->
      <section class="reviews" id="reviews">
        <div class="container">
          <h2 class="reviews_header">What our students say</h2>

          <div class="reviews_slider">
            <i class="icon-quote-left-solid icon"></i>
            <div class="swiper-wrapper">
              <div class="reviews_slider-slide swiper-slide">
                <q class="quote">
                  “StarLab has been the game-changer for me! Not only has it significantly boosted my graphics design skills. The platform"s engaging resources and supportive community have helped me grow both creatively and personally. I'm grateful for the experience and excited to continue learning and growing with StarLab! ”
                </q>
                <div class="author d-flex flex-column align-items-center">
                  <span class="avatar">
                    <picture>
                      <source
                        data-srcset="./img/profile-dp/eniolagabadamosi.jpeg"
                        srcset="./img/profile-dp/eniolagabadamosi.jpeg"
                      />
                      <img
                        class="lazy"
                        data-src="./img/profile-dp/eniolagabadamosi.jpeg"
                        src="./img/profile-dp/eniolagabadamosi.jpeg"
                        alt="media"
                      />
                    </picture>
                  </span>
                  <span class="name h5"> Gbadamosi Eniola </span>
                  <ul class="rating d-flex align-items-center">
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="reviews_slider-slide swiper-slide">
                <q class="quote">
                  “StarLab has helped increase my knowledge in graphic design and also helped me build my self self-esteem, this Academy is the best you can get .”
                </q>
                <div class="author d-flex flex-column align-items-center">
                  <span class="avatar">
                    <picture>
                      <source
                        data-srcset="./img/profile-dp/damilarearemu.jpeg"
                        srcset="./img/profile-dp/damilarearemu.jpeg"
                      />
                      <img
                        class="lazy"
                        data-src="./img/profile-dp/damilarearemu.jpeg"
                        src="./img/profile-dp/damilarearemu.jpeg"
                        alt="media"
                      />
                    </picture>
                  </span>
                  <span class="name h5"> Aremu Damilare </span>
                  <ul class="rating d-flex align-items-center">
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="reviews_slider-slide swiper-slide">
                <q class="quote">
                  “StarLab has also been the game-changer for me! Not only has it significantly boosted my programming skills by offering real life projects to harness ny skills ,
                   but it has also played a profound role in building the right mindset towards work ethics as a web developer.”
                </q>
                <div class="author d-flex flex-column align-items-center">
                  <span class="avatar">
                    <picture>
                      <source
                        data-srcset="./img/profile-dp/prospermarshalls.jpeg"
                        srcset="./img/profile-dp/prospermarshalls.jpeg"
                      />
                      <img
                        class="lazy"
                        data-src="./img/profile-dp/prospermarshalls.jpeg"
                        src="./img/profile-dp/prospermarshalls.jpeg"
                        alt="media"
                      />
                    </picture>
                  </span>
                  <span class="name h5"> Marshall Prosper </span>
                  <ul class="rating d-flex align-items-center">
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="reviews_slider-slide swiper-slide">
                <q class="quote">
                  “StarLab has helped increase my knowledge in content creation and management and also helped build my self-esteem, it has also been a very fun place for learning .”
                </q>
                <div class="author d-flex flex-column align-items-center">
                  <span class="avatar">
                    <picture>
                      <source
                        data-srcset="./img/profile-dp/preciosogoh.jpeg"
                        srcset="./img/profile-dp/preciosogoh.jpeg"
                      />
                      <img
                        class="lazy"
                        data-src="./img/profile-dp/preciosogoh.jpeg"
                        src="./img/profile-dp/preciosogoh.jpeg"
                        alt="media"
                      />
                    </picture>
                  </span>
                  <span class="name h5"> Ogoh Precious </span>
                  <ul class="rating d-flex align-items-center">
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="reviews_slider-slide swiper-slide">
                <q class="quote">
                  “StarLab has helped increase my knowledge in web development and also helped me build a good future for myself, it has also been a very fun place for learning especially as a frontend web developer.”
                </q>
                <div class="author d-flex flex-column align-items-center">
                  <span class="avatar">
                    <picture>
                      <source
                        data-srcset="./img/profile-dp/divinebanjoko.jpeg"
                        srcset="./img/profile-dp/divinebanjoko.jpeg"
                      />
                      <img
                        class="lazy"
                        data-src="./img/profile-dp/divinebanjoko.jpeg"
                        src="./img/profile-dp/divinebanjoko.jpeg"
                        alt="media"
                      />
                    </picture>
                  </span>
                  <span class="name h5"> Banjoko Divine </span>
                  <ul class="rating d-flex align-items-center">
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div
              class="reviews_slider-controls d-flex align-items-center justify-content-between"
            >
              <a class="swiper-button-prev" href="#">
                <i class="icon-angle-left icon"></i>
              </a>
              <a class="swiper-button-next" href="#">
                <i class="icon-angle-right icon"></i>
              </a>
            </div>
          </div>
        </div>
      </section>
      <!-- reviews section end -->
      <!-- faq section start -->
      <section class="faq">
        <div class="phone">
          <lottie-player
            src="lottie/phone.json"
            background="transparent"
            speed="1"
            style="width: 100%; height: 100%"
            loop
            autoplay
          ></lottie-player>
        </div>
        <div class="sphere">
          <lottie-player
            src="lottie/sphere.json"
            background="transparent"
            speed="1.5"
            style="width: 100%; height: 100%"
            loop
            autoplay
          ></lottie-player>
        </div>
        <div class="container d-flex flex-column align-items-center">
          <div class="faq_header">
            <h2 class="faq_header-title" data-aos="fade-down">
              Answering your common questions
            </h2>
          </div>
          <div class="faq_accordion" id="faq_accordion">
            <!-- item 1 -->
            <div class="faq_accordion-item">
              <div class="item-wrapper">
                <h4
                  class="faq_accordion-item_header d-flex justify-content-between align-items-center collapsed"
                  data-bs-toggle="collapse"
                  data-bs-target="#item-1"
                  aria-expanded="true"
                >
                  <span class="text">
                    What do i need to join this program?
                  </span>
                  <span class="icon transform"></span>
                </h4>
                <div id="item-1" class="accordion-collapse collapse show">
                  <div class="faq_accordion-item_body">
                    StarLab has created a form to properly access students joining this program. If you are interested in joining now tap the link <a href="https://bit.ly/starlabentryform" style="color: blue;">HERE</a> to direct you to the form .
                  </div>
                </div>
              </div>
            </div>
            <!-- item 2 -->
            <div class="faq_accordion-item">
              <div class="item-wrapper">
                <h4
                  class="faq_accordion-item_header d-flex justify-content-between align-items-center collapsed"
                  data-bs-toggle="collapse"
                  data-bs-target="#item-2"
                  aria-expanded="false"
                >
                  <span class="text">
                    What oppurtunities are available for me?
                  </span>
                  <span class="icon"></span>
                </h4>
                <div id="item-2" class="accordion-collapse collapse">
                  <div class="faq_accordion-item_body">
                    StarLab is dedicated in providing students skills and opportunities that would help students excel in thier various fields tech wise. For More Info visit: <a href="https://bit.ly/starlabentryform" style="color: blue;">HERE</a> .
                  </div>
                </div>
              </div>
            </div>
            <!-- item 3 -->
            <div class="faq_accordion-item">
              <div class="item-wrapper">
                <h4
                  class="faq_accordion-item_header d-flex justify-content-between align-items-center collapsed"
                  data-bs-toggle="collapse"
                  data-bs-target="#item-3"
                  aria-expanded="false"
                >
                  <span class="text">
                    What are the basic requirements to be part of this program?
                  </span>
                  <span class="icon"></span>
                </h4>
                <div id="item-3" class="accordion-collapse collapse">
                  <div class="faq_accordion-item_body">
                    Due to the nature of this program it is adviced that students must be done with there secondary school before applying. For More Info visit: <a href="https://bit.ly/starlabentryform" style="color: blue;">HERE</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a class="faq_btn btn--arrow" href="./404.php"
            >View all<i class="icon-arrow-right-solid icon"></i
          ></a>
        </div>
      </section>

      <!-- faq section end -->
    </main>
    <!-- about content end -->
    <?php include 'footer.php'; ?>
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
    <script src="js/common.min.js"></script>
    <script src="js/reviews.min.js"></script>
  </body>
</html>
