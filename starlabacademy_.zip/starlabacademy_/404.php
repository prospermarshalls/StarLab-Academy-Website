<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <title>404 | Edison</title>
        <script id="www-widgetapi-script" src="https://s.ytimg.com/yts/jsbin/www-widgetapi-vflS50iB-/www-widgetapi.js" async=""></script>
        <script src="https://www.youtube.com/player_api"></script>
        <link rel="stylesheet preload" as="style" href="css/preload.min.css" />
        <link rel="stylesheet preload" as="style" href="css/icomoon.css" />
        <link rel="stylesheet preload" as="style" href="css/libs.min.css" />
        <link rel="stylesheet" href="css/error.min.css" />
    </head>
    <body class="d-flex flex-column">
        <main class="error d-flex justify-content-center align-items-center flex-grow-1">
            <div class="container">
                <div class="error_media d-flex flex-column align-items-center">
                    <lottie-player
                        src="lottie/404.json"
                        background="transparent"
                        speed="1"
                        style="width: 100%; height: 100%"
                        loop
                        autoplay
                    ></lottie-player>
                    <div class="error_media-code d-flex align-items-center">
                        <div class="wrapper" data-aos="fade-in">
                            <div class="four four--left">
                                <picture>
                                    <source data-srcset="img/placeholder.jpg" srcset="img/placeholder.jpg" />
                                    <img class="lazy" data-src="img/placeholder.jpg" src="img/placeholder.jpg" alt="media" />
                                </picture>
                            </div>
                        </div>
                        <div class="wrapper" data-aos="fade-in" data-aos-delay="50">
                            <div class="zero">
                                <picture>
                                    <source data-srcset="img/placeholder.jpg" srcset="img/placeholder.jpg" />
                                    <img class="lazy" data-src="img/placeholder.jpg" src="img/placeholder.jpg" alt="media" />
                                </picture>
                                <div class="subwrapper" data-aos="fade-in" data-aos-delay="100">
                                    <div class="zero_search">
                                        <picture>
                                            <source data-srcset="img/placeholder.jpg" srcset="img/placeholder.jpg" />
                                            <img class="lazy" data-src="img/placeholder.jpg" src="img/placeholder.jpg" alt="media" />
                                        </picture>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="four four--right" data-aos="fade-in" data-aos-delay="150">
                            <div class="wrapper">
                                <picture>
                                    <source data-srcset="img/placeholder.jpg" srcset="img/placeholder.jpg" />
                                    <img class="lazy" data-src="img/placeholder.jpg" src="img/placeholder.jpg" alt="media" />
                                </picture>
                            </div>
                        </div>
                    </div>
                </div>
                <p class="error_message h4">
                    <span>Sorry, we can't find that page!</span>
                    <span>Don't worry though, everything is STILL AWESOME!</span>
                </p>
                <a class="error_btn btn--gradient btn" href="./index.php">
                    <span class="text">Back to Home page</span>
                </a>
            </div>
        </main>
        <footer class="footer d-flex justify-content-center align-items-center">
            <a class="footer_logo" href="index.html">
                <span class="logo_picture">
                    <img src="svg/SLlogo.svg" alt="Edison" />
                  </span>
            </a>
        </footer>
        <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
        <script src="js/error.min.js"></script>
    </body>
</html>
