
<footer class="footer">
  <div class="container">
    <div
      class="footer_wrapper d-sm-flex flex-wrap flex-lg-nowrap justify-content-lg-between"
    >
      <div class="footer_block col-sm-6 col-lg-auto" data-order="1">
        <div class="logo logo--footer">
          <a class="d-inline-flex align-items-center" href="#">
            <span class="logo_picture">
              <img src="svg/SLlogo.svg" alt="StarLab Academy" />
            </span>
            <span class="text">
              <span class="brand">StarLab</span>
              <span class="text_secondary">A c a d e m y </span>
            </span>
          </a>
        </div>
        <p class="footer_block-text">
          Enjoy quality lectures on-site and remotely from qualified
          personnel.
        </p>
        <ul class="footer_block-socials d-flex align-items-center">
          <li class="footer_block-socials_item">
            <a
              class="link"
              href="https://www.facebook.com/starlabacademy"
              target="_blank"
              rel="noopener noreferrer"
            >
              <i class="icon-facebook"></i>
            </a>
          </li>
          <li class="footer_block-socials_item">
            <a
              class="link"
              href="https://www.twitter.com/starlab_academy"
              target="_blank"
              rel="noopener noreferrer"
            >
              <i class="icon-twitter"></i>
            </a>
          </li>
          <li class="footer_block-socials_item">
            <a
              class="link"
              href="https://www.instagram.com/starlabacademy"
              target="_blank"
              rel="noopener noreferrer"
            >
              <i class="icon-instagram"></i>
            </a>
          </li>
        </ul>
        <div class="wrapper d-flex flex-column">
          <a
            class="link link--contacts text text--sm d-inline-flex align-items-center"
            href="mailto:starlabacademy15@gmail.com"
          >
            <i class="icon-envelope icon"></i>
            starlabacademy15@gmail.com
          </a>
          <a
            class="link link--contacts text text--sm d-inline-flex align-items-center"
            href="tel:+2348166499676"
          >
            <i class="icon-phone-solid icon"></i>
            +234-816-649-9676
          </a>
        </div>
      </div>
      <div class="footer_block col-sm-6 col-lg-auto" data-order="2">
        <h5 class="footer_block-header">Information:</h5>
        <ul class="footer_block-nav">
         
          <li class="footer_block-nav_item">
            <a class="link" href="./contacts.php">Contact Us</a>
          </li>
          <li class="footer_block-nav_item">
            <a class="link" href="./courses.php">All Courses</a>
          </li>
          <li class="footer_block-nav_item">
            <a class="link" href="https://www.linkedin.com/school/starlabacademy/">Recent Posts</a>
          </li>
          <li class="footer_block-nav_item">
            <a class="link" href="./contacts.php">FAQ</a>
          </li>
        </ul>
      </div>
      <div class="footer_block col-sm-6 col-lg-auto m-sm-0" data-order="3">
        <h5 class="footer_block-header">Popular Courses:</h5>
        <ul class="footer_block-list">
          <li class="footer_block-list_item d-flex align-items-baseline">
            <span class="marker"></span>
            <a class="link" href="./courses.php"
              >Software Engineering Fundamentals</a
            >
          </li>
          <li class="footer_block-list_item d-flex align-items-baseline">
            <span class="marker"></span>
            <a class="link" href="./courses.php"
              >
              Responsive Website : Code with HTML, CSS, JS</a
            >
          </li>
          <li class="footer_block-list_item d-flex align-items-baseline">
            <span class="marker"></span>
            <a class="link" href="./courses.php">Graphics Design Master class</a>
          </li>
        </ul>
      </div>
      <div class="footer_block col-sm-6 col-lg-auto" data-order="4">
        <h5 class="footer_block-header">Highlights:</h5>
        <ul class="footer_block-instagram d-grid">
          <li class="footer_block-instagram_item">
            <a
              class="link"
              href="https://www.linkedin.com/school/starlabacademy/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <picture>
                <source
                  data-srcset="./img/about.jpeg"
                  srcset="./img/about.jpeg"
                />
                <img
                  class="lazy"
                  data-src="./img/about.jpeg"
                  src="./img/about.jpeg"
                  alt="media"
                />
              </picture>
            </a>
          </li>
          <li class="footer_block-instagram_item">
            <a
              class="link"
              href="https://www.instagram.com/stories/highlights/17976906320735466/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <picture>
                <source
                  data-srcset="./img/contactus.jpeg"
                  srcset="./img/contactus.jpeg"
                />
                <img
                  class="lazy"
                  data-src="./img/contactus.jpeg"
                  src="./img/contactus.jpeg"
                  alt="media"
                />
              </picture>
            </a>
          </li>
          <li class="footer_block-instagram_item">
            <a
              class="link"
              href="https://www.instagram.com/stories/highlights/18105014986423286/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <picture>
                <source
                  data-srcset="./img/Courses.jpeg"
                  srcset="./img/Courses.jpeg"
                />
                <img
                  class="lazy"
                  data-src="./img/Courses.jpeg"
                  src="./img/Courses.jpeg"
                  alt="media"
                />
              </picture>
            </a>
          </li>
          <li class="footer_block-instagram_item">
            <a
              class="link"
              href="https://www.instagram.com/stories/highlights/17930485988921775/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <picture>
                <source
                  data-srcset="./img/events.jpeg"
                  srcset="./img/events.jpeg"
                />
                <img
                  class="lazy"
                  data-src="./img/events.jpeg"
                  src="./img/events.jpeg"
                  alt="media"
                />
              </picture>
            </a>
          </li>
          <li class="footer_block-instagram_item">
            <a
              class="link"
              href="https://www.instagram.com/stories/highlights/18453464098031411/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <picture>
                <source
                  data-srcset="./img/Projects.jpeg"
                  srcset="./img/Projects.jpeg"
                />
                <img
                  class="lazy"
                  data-src="./img/Projects.jpeg"
                  src="./img/Projects.jpeg"
                  alt="media"
                />
              </picture>
            </a>
          </li>
          <li class="footer_block-instagram_item">
            <a
              class="link"
              href="https://www.instagram.com/stories/highlights/17981312672725268/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <picture>
                <source
                  data-srcset="./img/about.jpeg"
                  srcset="./img/about.jpeg"
                />
                <img
                  class="lazy"
                  data-src="./img/about.jpeg"
                  src="./img/about.jpeg"
                  alt="media"
                />
              </picture>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <div class="footer_secondary">
    <div
      class="container d-flex flex-column flex-sm-row align-items-center justify-content-sm-between"
    >
      <a class="footer_secondary-scroll" id="scrollToTop"  href="">
        <i class="icon-angle-up icon"></i>
      </a>
      <p class="footer_secondary-copyright">
        Copyright @ <span id="currentYear"></span> StarLab Academy
      </p>
    </div>
  </div>
</footer>

