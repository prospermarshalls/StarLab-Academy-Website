<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, minimum-scale=1.0"
    />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="shortcut icon" href="./svg/android-chrome-192x192.png" type="image/x-icon">
    <title>Contact Us | Starlab</title>
    <script
      id="www-widgetapi-script"
      src="https://s.ytimg.com/yts/jsbin/www-widgetapi-vflS50iB-/www-widgetapi.js"
      async=""
    ></script>
    <script src="https://www.youtube.com/player_api"></script>
    <link rel="stylesheet preload" as="style" href="css/preload.min.css" />
    <link rel="stylesheet preload" as="style" href="css/icomoon.css" />
    <link rel="stylesheet preload" as="style" href="css/libs.min.css" />

    <link rel="stylesheet" href="css/contacts.min.css" />
  </head>
  <body>
  <?php include 'header.php'; ?>
    <!-- contacts content start -->
    <main class="contacts">
      <section class="contacts_form">
        <div class="container">
          <div class="contacts_form-header">
            <h2 class="contacts_form-header_title">
              Our experts will help you
            </h2>

            <p class="contacts_form-header_text text">
              If you have questions about the format or do not know what to
              choose, leave your request: we will be happy to answer all your
              questions.
            </p>
          </div>
          <form
  class="contacts_form-form"
  action="form.php"
  method="POST"
  data-type="contacts"
>
  <div
    class="contacts_form-form_wrapper d-sm-flex justify-content-between"
  >
    <input
      class="field required"
      type="text"
      name="contactsEmail" 
      data-type="email"
      placeholder="Email"
      id="contactsEmail"
      
    />
    <input
      class="field required"
      type="text"
      name="contactsName" 
      placeholder="Name"
      id="contactsName"
    />
  </div>
  <div
    class="contacts_form-form_wrapper d-sm-flex justify-content-between"
  >
    <input
      class="field required"
      type="text"
      name="contactsTel" 
      data-type="tel"
      placeholder="Phone number"
      id="contactsTel"
    />
    <input
      class="field required"
      type="text"
      name="contactsSubject" 
      placeholder="Subject"
      id="contactsSubject"
    />
  </div>
  <textarea
    class="field required"
    name="contactsMessage" 
    placeholder="Your message here"
    data-type="message"
    id="contactsMessage"
  ></textarea>
  <div class="contacts_form-form_footer">
    <div
      class="wrapper d-flex flex-wrap align-items-center justify-content-center"
    >
      <div class="checkbox">
        <input
          type="checkbox"
          name="dataProcessing"
          id="dataProcessing"
          checked
        />
        <label for="dataProcessing">
          <i class="icon-check icon"></i>
          I agree to the terms of data processing.
        </label>
      </div>
      <a class="link" href="./404.php">Terms and Conditions</a>
    </div>
    <button class="btn btn--gradient" type="submit">
      <span class="text">Send a Message</span>
    </button>
  </div>
</form>

        </div>
      </section>
      <div class="contacts_map">
        <div id="map"></div>
      </div>
    </main>
    <!-- contacts content end -->
    <?php include 'footer.php'; ?>
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
    <script src="js/common.min.js"></script>
    <script src="js/map.min.js"></script>
  </body>
</html>
