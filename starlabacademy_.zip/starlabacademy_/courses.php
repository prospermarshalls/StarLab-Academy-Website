<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, minimum-scale=1.0"
    />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="shortcut icon" href="./svg/android-chrome-192x192.png" type="image/x-icon">
    <title>All courses | Starlab</title>
    <script
      id="www-widgetapi-script"
      src="https://s.ytimg.com/yts/jsbin/www-widgetapi-vflS50iB-/www-widgetapi.js"
      async=""
    ></script>
    <script src="https://www.youtube.com/player_api"></script>
    <link rel="stylesheet preload" as="style" href="css/preload.min.css" />
    <link rel="stylesheet preload" as="style" href="css/icomoon.css" />
    <link rel="stylesheet preload" as="style" href="css/libs.min.css" />
    <link rel="stylesheet" href="css/courses.min.css" />
  </head>
  <body>
  <?php include 'header.php'; ?>
    <header class="page">
      <div class="page_breadcrumbs">
        <div class="container">
          <ul class="page_breadcrumbs-list d-flex flex-wrap align-items-center">
            <li class="list-item">
              <a href="index.html" class="link">Home</a>
            </li>

            <li class="list-item">All courses</li>
          </ul>
        </div>
      </div>

      <div class="page_main">
        <div class="underlay"></div>
        <div class="container">
          <div class="content-wrapper">
            <h1 class="page_main-header">Large selection of courses</h1>
            <p class="page_main-text">
            Explore a wide range of courses, from web development and design to content management,
             tailored to equip you with the skills you need
            </p>

            <form
              class="page_main-form"
              action="#"
              method="post"
              data-type="search"
            >
              <i class="icon-search-solid icon"></i>
              <input
                class="field required"
                type="search"
                placeholder="Search for…"
              />
            </form>
          </div>
        </div>
      </div>
    </header>
    <!-- courses content start -->
    <main>
      <!-- courses list section start -->
      <section class="list">
        <div class="container">
          <!-- <ul
            class="list_tags courses-tags d-flex flex-wrap align-items-center justify-content-center"
          >
            <li class="list-item" data-aos="fade-left">
              <a data-target="all" class="list_tags-tag tag current" href="#"
                >all</a
              >
            </li>
            <li class="list-item" data-aos="fade-left" data-aos-delay="50">
              <a data-target="programming" class="list_tags-tag tag" href="#"
                >programming</a
              >
            </li>
            <li class="list-item" data-aos="fade-left" data-aos-delay="100">
              <a data-target="management" class="list_tags-tag tag" href="#"
                >management</a
              >
            </li>
            <li class="list-item" data-aos="fade-left" data-aos-delay="150">
              <a data-target="art" class="list_tags-tag tag" href="#">art</a>
            </li>
            <li class="list-item" data-aos="fade-left" data-aos-delay="200">
              <a data-target="marketing" class="list_tags-tag tag" href="#"
                >digital marketing</a
              >
            </li>
            <li class="list-item" data-aos="fade-left" data-aos-delay="250">
              <a data-target="gamedev" class="list_tags-tag tag" href="#"
                >game development</a
              >
            </li>
            <li class="list-item" data-aos="fade-left" data-aos-delay="300">
              <a data-target="smm" class="list_tags-tag tag" href="#">smm</a>
            </li>
          </ul> -->
          <ul class="list_courses d-md-flex flex-wrap">
            <li
              class="list_courses-card course-card col-12 col-md-6 col-xl-4"
              data-groups='["gamedev", "programming"]'
            >
              <div class="course-card_wrapper">
                <div class="top d-flex align-items-start">
                  <span class="top_icon top_icon--blue">
                    <i class="icon-code-solid icon"></i>
                  </span>
                  <div class="wrapper d-flex flex-column">
                    <h5 class="top_title">Software Engineering Fundamentals</h5>
                    <ul class="rating d-flex align-items-center">
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                    </ul>
                    <span class="top_author">by Starlab Academy</span>
                    <span class="top_details">48 lectures ( 280 Hours)</span>
                  </div>
                </div>
                <!-- <div class="pricing">
                  <span class="pricing_price h5"
                    >$120 all course / $20 per month</span
                  >
                </div> -->
                <div class="bottom">
                  <a
                    class="bottom_btn btn btn--bordered btn--arrow"
                    href="https://bit.ly/starlabentryform"
                  >
                    sign up for a course
                    <i class="icon-arrow-right-solid icon"></i>
                  </a>
                </div>
              </div>
            </li>
            <li
              class="list_courses-card course-card col-12 col-md-6 col-xl-4"
              data-groups='["programming"]'
            >
              <div class="course-card_wrapper">
                <div class="top d-flex align-items-start">
                  <span class="top_icon top_icon--orange">
                    <i class="icon-project-diagram-solid icon"></i>
                  </span>
                  <div class="wrapper d-flex flex-column">
                    <h5 class="top_title">
                      Introduction to Python as a Second Language
                    </h5>
                    <ul class="rating d-flex align-items-center">
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                    </ul>
                    <span class="top_author">by Starlab Academy</span>
                    <span class="top_details">48 lectures ( 280 Hours)</span>
                  </div>
                </div>
                <!-- <div class="pricing">
                  <span class="pricing_price h5"
                    >$120 all course / $20 per month</span
                  >
                </div> -->
                <div class="bottom">
                  <a
                    class="bottom_btn btn btn--bordered btn--arrow"
                    href="https://bit.ly/starlabentryform"
                  >
                    sign up for a course
                    <i class="icon-arrow-right-solid icon"></i>
                  </a>
                </div>
              </div>
            </li>
            <li
              class="list_courses-card course-card col-12 col-md-6 col-xl-4"
              data-groups='["art", "programming"]'
            >
              <div class="course-card_wrapper">
                <div class="top d-flex align-items-start">
                  <span class="top_icon top_icon--sky">
                    <i class="icon-window-restore-solid icon"></i>
                  </span>
                  <div class="wrapper d-flex flex-column">
                    <h5 class="top_title">
                      Graphics Design: Branding and Brandbook Creation.
                    </h5>
                    <ul class="rating d-flex align-items-center">
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                    </ul>
                    <span class="top_author">by Starlab Academy</span>
                    <span class="top_details">48 lectures ( 280 Hours)</span>
                  </div>
                </div>
                <!-- <div class="pricing">
                  <span class="pricing_price h5"
                    >$120 all course / $20 per month</span
                  >
                </div> -->
                <div class="bottom">
                  <a
                    class="bottom_btn btn btn--bordered btn--arrow"
                    href="https://bit.ly/starlabentryform"
                  >
                    sign up for a course
                    <i class="icon-arrow-right-solid icon"></i>
                  </a>
                </div>
              </div>
            </li>
            <li
              class="list_courses-card course-card col-12 col-md-6 col-xl-4"
              data-groups='["art", "gamedev", "marketing"]'
            >
              <div class="course-card_wrapper">
                <div class="top d-flex align-items-start">
                  <span class="top_icon top_icon--pink">
                    <i class="icon-laptop-code-solid icon"></i>
                  </span>
                  <div class="wrapper d-flex flex-column">
                    <h5 class="top_title">
                      Photography and Photo Editing : Photoshop 
                    </h5>
                    <ul class="rating d-flex align-items-center">
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                    </ul>
                    <span class="top_author">by Starlab Academy</span>
                    <span class="top_details">48 lectures ( 280 Hours)</span>
                  </div>
                </div>
                <!-- <div class="pricing">
                  <span class="pricing_price h5"
                    >$120 all course / $20 per month</span
                  >
                </div> -->
                <div class="bottom">
                  <a
                    class="bottom_btn btn btn--bordered btn--arrow"
                    href="https://bit.ly/starlabentryform"
                  >
                    sign up for a course
                    <i class="icon-arrow-right-solid icon"></i>
                  </a>
                </div>
              </div>
            </li>
            <li
              class="list_courses-card course-card col-12 col-md-6 col-xl-4"
              data-groups='["art", "gamedev", "marketing"]'
            >
              <div class="course-card_wrapper">
                <div class="top d-flex align-items-start">
                  <span class="top_icon top_icon--blue">
                    <i class="icon-chart-line-solid icon"></i>
                  </span>
                  <div class="wrapper d-flex flex-column">
                    <h5 class="top_title">
                      Content Writing and Social Media Management
                    </h5>
                    <ul class="rating d-flex align-items-center">
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                    </ul>
                    <span class="top_author">by Starlab Academy</span>
                    <span class="top_details">48 lectures ( 280 Hours)</span>
                  </div>
                </div>
                <!-- <div class="pricing">
                  <span class="pricing_price h5"
                    >$120 all course / $20 per month</span
                  >
                </div> -->
                <div class="bottom">
                  <a
                    class="bottom_btn btn btn--bordered btn--arrow"
                    href="https://bit.ly/starlabentryform"
                  >
                    sign up for a course
                    <i class="icon-arrow-right-solid icon"></i>
                  </a>
                </div>
              </div>
            </li>
            <li
              class="list_courses-card course-card col-12 col-md-6 col-xl-4"
              data-groups='["programming", "management"]'
            >
              <div class="course-card_wrapper">
                <div class="top d-flex align-items-start">
                  <span class="top_icon top_icon--orange">
                    <i class="icon-code-branch-solid icon"></i>
                  </span>
                  <div class="wrapper d-flex flex-column">
                    <h5 class="top_title">
                      Introduction to Programming with Python
                    </h5>
                    <ul class="rating d-flex align-items-center">
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                    </ul>
                    <span class="top_author">by Starlab Academy</span>
                    <span class="top_details">48 lectures ( 280 Hours)</span>
                  </div>
                </div>
                <!-- <div class="pricing">
                  <span class="pricing_price h5"
                    >$120 all course / $20 per month</span
                  >
                </div> -->
                <div class="bottom">
                  <a
                    class="bottom_btn btn btn--bordered btn--arrow"
                    href="https://bit.ly/starlabentryform"
                  >
                    sign up for a course
                    <i class="icon-arrow-right-solid icon"></i>
                  </a>
                </div>
              </div>
            </li>
            <li
              class="list_courses-card course-card col-12 col-md-6 col-xl-4"
              data-groups='["art", "management", "smm"]'
            >
              <div class="course-card_wrapper">
                <div class="top d-flex align-items-start">
                  <span class="top_icon top_icon--blue">
                    <i class="icon-gem-solid icon"></i>
                  </span>
                  <div class="wrapper d-flex flex-column">
                    <h5 class="top_title">
                      Advanced Statistics for Data Science and Data Analysis
                    </h5>
                    <ul class="rating d-flex align-items-center">
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                    </ul>
                    <span class="top_author">by Starlab Academy</span>
                    <span class="top_details">48 lectures ( 280 Hours)</span>
                  </div>
                </div>
                <!-- <div class="pricing">
                  <span class="pricing_price h5"
                    >$120 all course / $20 per month</span
                  >
                </div> -->
                <div class="bottom">
                  <a
                    class="bottom_btn btn btn--bordered btn--arrow"
                    href="https://bit.ly/starlabentryform"
                  >
                    sign up for a course
                    <i class="icon-arrow-right-solid icon"></i>
                  </a>
                </div>
              </div>
            </li>
            <li
              class="list_courses-card course-card col-12 col-md-6 col-xl-4"
              data-groups='["marketing", "management", "smm"]'
            >
              <div class="course-card_wrapper">
                <div class="top d-flex align-items-start">
                  <span class="top_icon top_icon--pink">
                    <i class="icon-coins-solid icon"></i>
                  </span>
                  <div class="wrapper d-flex flex-column">
                    <h5 class="top_title">Videography and Video Editing Adobe Premier </h5>
                    <ul class="rating d-flex align-items-center">
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                    </ul>
                    <span class="top_author">by Starlab Academy</span>
                    <span class="top_details">48 lectures ( 280 Hours)</span>
                  </div>
                </div>
                <!-- <div class="pricing">
                  <span class="pricing_price h5"
                    >$120 all course / $20 per month</span
                  >
                </div> -->
                <div class="bottom">
                  <a
                    class="bottom_btn btn btn--bordered btn--arrow"
                    href="https://bit.ly/starlabentryform"
                  >
                    sign up for a course
                    <i class="icon-arrow-right-solid icon"></i>
                  </a>
                </div>
              </div>
            </li>
            <li
              class="list_courses-card course-card col-12 col-md-6 col-xl-4"
              data-groups='["marketing", "management", "smm"]'
            >
              <div class="course-card_wrapper">
                <div class="top d-flex align-items-start">
                  <span class="top_icon top_icon--sky">
                    <i class="icon-code-branch-solid icon"></i>
                  </span>
                  <div class="wrapper d-flex flex-column">
                    <h5 class="top_title">
                      Responsive Web Design with HTML and CSS
                    </h5>
                    <ul class="rating d-flex align-items-center">
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                    </ul>
                    <span class="top_author">by Starlab Academy</span>
                    <span class="top_details">48 lectures ( 280 Hours)</span>
                  </div>
                </div>
                <!-- <div class="pricing">
                  <span class="pricing_price h5"
                    >$120 all course / $20 per month</span
                  >
                </div> -->
                <div class="bottom">
                  <a
                    class="bottom_btn btn btn--bordered btn--arrow"
                    href="https://bit.ly/starlabentryform"
                  >
                    sign up for a course
                    <i class="icon-arrow-right-solid icon"></i>
                  </a>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </section>
      <!-- courses list section end -->
      <!-- sale section start -->
      <section class="sale" style=" background: -o-linear-gradient(
    298.11deg,
    rgb(0, 0, 0) 6.97%,
    rgb(242, 101, 34) 84.71%
  );
  background: linear-gradient(
    151.89deg,
    rgb(0, 0, 0) 6.97%,
    rgb(242, 101, 34) 84.71%
  ); ">
        <!-- <div class="sale_deco">
          <picture>
            <source
              data-srcset="img/placeholder.jpg"
              srcset="img/placeholder.jpg"
            />
            <img
              class="lazy"
              data-src="img/placeholder.jpg"
              src="img/placeholder.jpg"
              alt="media"
            />
          </picture>
        </div> -->
        <div class="container">
          <div class="sale_content">
            <div
              class="content d-flex flex-column flex-sm-row align-items-center align-items-sm-start"
            >
              <span class="content_percent">50%</span>
              <div
                class="content_text d-flex flex-column align-items-center align-items-sm-start"
              >
                <h3 class="title">
                  <span class="percent">50%</span> Season sale
                </h3>
                <p class="text">
                  Unlimited access to educational materials and lectures
                </p>
              </div>
            </div>
            <form
              class="form d-flex flex-column flex-sm-row"
              action="#"
              method="post"
              data-type="subscription"
            >
              <input
                class="field required"
                type="text"
                placeholder="Subscribe by e-mail"
              />
              <button class="btn btn--gradient" type="submit">
                <span class="text">Get Started Now</span>
              </button>
            </form>
          </div>
        </div>
      </section>
      <!-- sale section end -->
      <!-- reviews section start -->
      <section class="reviews" id="reviews">
        <div class="container">
          <h2 class="reviews_header">What our students say</h2>

          <div class="reviews_slider">
            <i class="icon-quote-left-solid icon"></i>
            <div class="swiper-wrapper">
              <div class="reviews_slider-slide swiper-slide">
                <q class="quote">
                  Taking courses on social media management has never been easier than the program starlab academy has made available I can proudly call myself a social media manager thanks to the well detailed and outlined courses provided at StarLab Academy . ”
                </q>
                <div class="author d-flex flex-column align-items-center">
                  <span class="avatar">
                    <picture>
                      <source
                        data-srcset="./img/profile-dp/preciosogoh.jpeg"
                        srcset="./img/profile-dp/preciosogoh.jpeg"
                      />
                      <img
                        class="lazy"
                        data-src="./img/profile-dp/preciosogoh.jpeg"
                        src="./img/profile-dp/preciosogoh.jpeg"
                        alt="media"
                      />
                    </picture>
                  </span>
                  <span class="name h5"> Ogoh Precious</span>
                  <ul class="rating d-flex align-items-center">
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="reviews_slider-slide swiper-slide">
                <q class="quote">
                  The Graphics design course has been simply awesome for me!  it is very easy to follow with poject based learning structure employed by StarLab Academy im very glad I got the opportunity to learn here!”
                </q>
                <div class="author d-flex flex-column align-items-center">
                  <span class="avatar">
                    <picture>
                      <source
                        data-srcset="./img/profile-dp/eniolagabadamosi.jpeg"
                        srcset="./img/profile-dp/eniolagabadamosi.jpeg"
                      />
                      <img
                        class="lazy"
                        data-src="./img/profile-dp/eniolagabadamosi.jpeg"
                        src="./img/profile-dp/eniolagabadamosi.jpeg"
                        alt="media"
                      />
                    </picture>
                  </span>
                  <span class="name h5"> Gbadamosi Eniola </span>
                  <ul class="rating d-flex align-items-center">
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="reviews_slider-slide swiper-slide">
                <q class="quote">
                  “The Web development courses were surprisingly easy to follow along it has fast tracked my learning process. Thank You StarLab Academy! .”
                </q>
                <div class="author d-flex flex-column align-items-center">
                  <span class="avatar">
                    <picture>
                      <source
                        data-srcset="./img/profile-dp/divinebanjoko.jpeg"
                        srcset="./img/profile-dp/divinebanjoko.jpeg"
                      />
                      <img
                        class="lazy"
                        data-src="./img/profile-dp/divinebanjoko.jpeg"
                        src="./img/profile-dp/divinebanjoko.jpeg"
                        alt="media"
                      />
                    </picture>
                  </span>
                  <span class="name h5"> Banjoko Divine </span>
                  <ul class="rating d-flex align-items-center">
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="reviews_slider-slide swiper-slide">
                <q class="quote">
                  “As a web developer finding detailed courses and resources has never been easy but following the courses provided at starlabacademy has been wonderful the self paced and project based learning helps alot in becoming a well rounded programmer .”
                </q>
                <div class="author d-flex flex-column align-items-center">
                  <span class="avatar">
                    <picture>
                      <source
                        data-srcset="./img/profile-dp/prospermarshalls.jpeg"
                        srcset="./img/profile-dp/prospermarshalls.jpeg"
                      />
                      <img
                        class="lazy"
                        data-src="./img/profile-dp/prospermarshalls.jpeg"
                        src="./img/profile-dp/prospermarshalls.jpeg"
                        alt="media"
                      />
                    </picture>
                  </span>
                  <span class="name h5"> Marshall Prosper</span>
                  <ul class="rating d-flex align-items-center">
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="reviews_slider-slide swiper-slide">
                <q class="quote">
                  “Taking the courses on Graphic Design and Branding
                   has been the game changer for me I have grown tremendously as a graphic designer since completing the course definitely recommend. ”
                </q>
                <div class="author d-flex flex-column align-items-center">
                  <span class="avatar">
                    <picture>
                      <source
                        data-srcset="./img/profile-dp/damilarearemu.jpeg"
                        srcset="./img/profile-dp/damilarearemu.jpeg"
                      />
                      <img
                        class="lazy"
                        data-src="./img/profile-dp/damilarearemu.jpeg"
                        src="./img/profile-dp/damilarearemu.jpeg"
                        alt="media"
                      />
                    </picture>
                  </span>
                  <span class="name h5"> Aremu Damilare</span>
                  <ul class="rating d-flex align-items-center">
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                    <li class="rating_star">
                      <i class="icon-star icon"></i>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div
              class="reviews_slider-controls d-flex align-items-center justify-content-between"
            >
              <a class="swiper-button-prev" href="#">
                <i class="icon-angle-left icon"></i>
              </a>
              <a class="swiper-button-next" href="#">
                <i class="icon-angle-right icon"></i>
              </a>
            </div>
          </div>
        </div>
      </section>
      <!-- reviews section end -->
    </main>
    <!-- courses content end -->
    <?php include 'footer.php'; ?>
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
    <script src="js/common.min.js"></script>
    <script src="js/reviews.min.js"></script>
    <script src="js/courses.min.js"></script>
  </body>
</html>
