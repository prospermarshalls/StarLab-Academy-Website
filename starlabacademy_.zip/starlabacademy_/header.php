
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="./css/index.min.css" />
    </head>
    <body>
    
    <div class="promobar d-flex align-items-center">
      <div class="container d-flex align-items-center justify-content-between">
        <ul class="promobar_socials d-flex align-items-center">
          <li class="promobar_socials-item">
            <a class="link" href="https://www.facebook.com/starlabacademy" target="_blank" rel="noopener noreferrer">
              <i class="icon-facebook"></i>
            </a>
          </li>
          <li class="promobar_socials-item">
            <a class="link" href="https://www.twitter.com/starlab_academy" target="_blank" rel="noopener noreferrer">
              <i class="icon-twitter"></i>
            </a>
          </li>
          <li class="promobar_socials-item">
            <a class="link" href="https://www.instagram.com/starlabacademy" target="_blank" rel="noopener noreferrer">
              <i class="icon-instagram"></i>
            </a>
          </li>
        </ul>
        <div class="promobar_main d-flex align-items-center">
          <p class="promobar_main-text">
            Try for free! <span class="hide"> Join Our Academy</span>
          </p>
          <a
            class="btn"
            style="background-color: #29323c; color: #fff"
            href="https://bit.ly/starlabentryform"
            id="signUpTrigge"
          >
            <span>Register</span>
          </a>
        </div>
      </div>
    </div>
    <header class="header" data-page="home">
      <div
        class="container d-flex flex-wrap justify-content-between align-items-center"
      >
        <div class="logo header_logo">
          <a class="d-inline-flex align-items-center" href="#">
            <span class="logo_picture">
              <img src="svg/SLlogo.svg" alt="Edison" />
            </span>
            <span class="text">
              <span class="brand">StarLab</span>
              <span class="text_secondary"> A c a d e m y </span>
            </span>
          </a>
        </div>
        <button
          class="header_trigger"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#headerMenu"
          aria-controls="headerMenu"
        >
          <span class="line"></span>
          <span class="line"></span>
          <span class="line"></span>
        </button>
        <nav class="header_nav collapse" id="headerMenu">
          <ul class="header_nav-list">
            <li class="header_nav-list_item ">
              <a class="nav-item" href="./index.php" data-page="home">Home</a>
            </li>
            <li class="header_nav-list_item ">
              <a class="nav-item" href="./about.php" data-page="about"
                >About Us</a
              >
            </li>
            <li class="header_nav-list_item dropdown">
              <a
                class="nav-link nav-item dropdown-toggle d-inline-flex align-items-center"
                href="./courses.php"
                data-bs-toggle="collapse"
                data-bs-target="#coursesMenu"
                data-trigger="dropdown"
                aria-expanded="false"
                aria-controls="coursesMenu"
                data-page="courses"
              >
                Programs
                <i class="icon-angle-down icon"></i>
              </a>
              <div class="dropdown-menu collapse" id="coursesMenu">
                <ul class="dropdown-list">
                  <!-- <li class="list-item" >
                    <a
                      class="dropdown-item nav-item"
                      data-page="courses"
                      href="./courses.php"
                      data-main="true"
                    >
                      Courses
                    </a>
                  </li> -->
                  <li class="list-item">
                    <a
                      class="dropdown-item nav-item"
                      data-page="course"
                      href="./404.php"
                      >Art & Creative Design</a
                    >
                  </li>
                  <li class="list-item">
                    <a
                      class="dropdown-item nav-item"
                      data-page="course"
                      href="./404.php"
                      >Software Development</a
                    >
                  </li>
                  <li class="list-item">
                    <a
                      class="dropdown-item nav-item"
                      data-page="course"
                      href="./404.php"
                      >Digital Media Production</a
                    >
                  </li>
                  <!-- <li class="list-item">
                    <a class="dropdown-item nav-item" data-page="courses"
                    href="./404.php"></a>
                  </li> -->
                  <li class="list-item">
                    <a
                      class="dropdown-item nav-item"
                      data-page="course"
                      href="https://bit.ly/starlabentryform"
                      >Academics Scholarship</a
                    >
                  </li>
                  <li class="list-item">
                    <a
                      class="dropdown-item nav-item"
                      data-page="course"
                      href="https://bit.ly/starlabentryform"
                      >Internship Opportunities</a
                    >
                  </li>
                  <li class="list-item">
                    <a
                      class="dropdown-item nav-item"
                      data-page="course"
                      href="./404.php"
                      >After School Classes</a
                    >
                  </li>
                </ul>
              </div>
            </li>
            <li class="header_nav-list_item">
              <a class="nav-ite" href="./404.php" data-page="pricing">Admission</a>
            </li>
            <!--<li class="header_nav-list_item">
                            <a class="nav-item" href="#" data-page="pricing">Prices</a>
                        </li> -->
            <li class="header_nav-list_item">
              <a class="nav-ite" href="https://starlabacademy.org/portal/" data-page="pricing">Portal</a>
            </li>
            <li class="header_nav-list_item dropdown">
              <a
                class="nav-link nav-ite dropdown-toggle d-inline-flex align-items-center"
                href="./404.php"
                data-bs-toggle="collapse"
                data-bs-target="#journalMenu"
                data-trigger="dropdown"
                aria-expanded="false"
                aria-controls="journalMenu"
                data-page="journal"
              >
                Resources
                <i class="icon-angle-down icon"></i>
              </a>
              <div class="dropdown-menu collapse" id="journalMenu">
                <ul class="dropdown-list">
                  <!-- <li class="list-item" data-main="true">
                                        <a class="dropdown-item nav-item" data-page="journal" href="./404.php" data-main="true">
                                            Journal
                                        </a>
                                    </li> -->
                  <li class="list-item">
                    <a class="dropdown-item nav-item" data-page="post" href="./404.php"
                      >Tech Trends</a
                    >
                  </li>
                  <li class="list-item">
                    <a class="dropdown-item nav-item" data-page="post" href="./404.php"
                      >Scholarship</a
                    >
                  </li>
                </ul>
              </div>
            </li>
            <!-- <li class="header_nav-list_item dropdown">
                            <a
                                class="nav-link nav-item dropdown-toggle d-inline-flex align-items-center"
                                href="./404.php"
                                data-bs-toggle="collapse"
                                data-bs-target="#pagesMenu"
                                data-trigger="dropdown"
                                aria-expanded="false"
                                aria-controls="pagesMenu"
                                data-page=""
                            >
                                Pages
                                <i class="icon-angle-down icon"></i>
                            </a>
                            <div class="dropdown-menu collapse" id="pagesMenu">
                                <ul class="dropdown-list">
                                    <li class="list-item">
                                        <a class="dropdown-item nav-item" data-page="library" href="#">Media library</a>
                                    </li>
                                    <li class="list-item">
                                        <a class="dropdown-item nav-item" data-page="course" href="#">Course Description</a>
                                    </li>
                                    <li class="list-item">
                                        <a class="dropdown-item nav-item" data-page="events" href="#">Events</a>
                                    </li>
                                    <li class="list-item">
                                        <a class="dropdown-item nav-item" data-page="post" href="#">Single Post</a>
                                    </li>
                                    <li class="list-item">
                                        <a class="dropdown-item nav-item" data-page="teachers" href="#">Teachers</a>
                                    </li>
                                    <li class="list-item">
                                        <a class="dropdown-item nav-item" data-page="faq" href="#">FAQ</a>
                                    </li>
                                    <li class="list-item">
                                        <a class="dropdown-item nav-item" data-page="error" href="#">404</a>
                                    </li>
                                </ul>
                            </div>
                        </li> -->
            <li class="header_nav-list_item">
              <a class="nav-item" href="./contacts.php" data-page="contacts"
                >Contact Us</a
              >
            </li>
          </ul>
          <ul
            class="promobar_socials d-flex align-items-center justify-content-center"
          >
            <li class="promobar_socials-item">
              <a
                class="link"
                href="https://www.facebook.com/starlabacademy"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i class="icon-facebook"></i>
              </a>
            </li>
            <li class="promobar_socials-item">
              <a
                class="link"
                href="https://www.twitter.com/starlab_academy"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i class="icon-twitter"></i>
              </a>
            </li>
            <li class="promobar_socials-item">
              <a
                class="link"
                href="https://www.instagram.com/starlabacademy"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i class="icon-instagram"></i>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </header>


   
  <script>
  document.addEventListener("DOMContentLoaded", () => {
    // Get the current page URL
    const currentPageUrl = window.location.pathname;
    
    // Extract the page name from the URL 
    const pageName = currentPageUrl.substring(currentPageUrl.lastIndexOf('/') + 1).split('.')[0];

    // Define page mapping.
    const pages = {
      'index': 'home',
      'about': 'about',
      'courses': 'courses',
      'contacts': 'contacts'
    };

    // Get the current page's data-page value, default to home
    const dataPage = pages[pageName] || 'home';

    // Set the data-page attribute dynamically
    document.querySelector("header").setAttribute("data-page", dataPage);
  });


</script>

    </body>
    </html>