<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, minimum-scale=1.0"
    />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="shortcut icon" href="./svg/android-chrome-192x192.png" type="image/x-icon">
    <title>Talent School | StarLab Academy</title>
    <script
      id="www-widgetapi-script"
      src="https://s.ytimg.com/yts/jsbin/www-widgetapi-vflS50iB-/www-widgetapi.js"
      async=""
    ></script>
    <script src="https://www.youtube.com/player_api"></script>
    <link rel="stylesheet preload" as="style" href="css/preload.min.css" />
    <link rel="stylesheet preload" as="style" href="css/icomoon.css" />
    <link rel="stylesheet preload" as="style" href="css/libs.min.css" />

    <link rel="stylesheet" href="./css/index.min.css" />
  </head>
  <body>
   <?php include './header.php'; ?> 
    <!-- homepage content start -->
    <main>
      <!-- hero section start -->
      <div class="underlay"></div>
      <section class="hero">
        <div class="container d-lg-flex align-items-center">
          <div class="hero_content">
            <h1 class="hero_content-header" data-aos="fade-up">
              Intensive EduTech Programs
            </h1>
            <div
              class="hero_content-rating d-flex flex-column flex-sm-row align-items-center"
            >
              <p class="text" data-aos="fade-left">
                Our classes are intensive and five-star rated
              </p>
              <div class="wrapper" data-aos="fade-left" data-aos-delay="50">
                <ul class="rating d-flex align-items-center">
                  <li class="rating_star">
                    <i class="icon-star icon"></i>
                  </li>
                  <li class="rating_star">
                    <i class="icon-star icon"></i>
                  </li>
                  <li class="rating_star">
                    <i class="icon-star icon"></i>
                  </li>
                  <li class="rating_star">
                    <i class="icon-star icon"></i>
                  </li>
                  <li class="rating_star">
                    <i class="icon-star icon"></i>
                  </li>
                </ul>
              </div>
            </div>
            <p class="hero_content-text" data-aos="fade-up" data-aos-delay="50">
              Our Academy has presently produced a widespread number of
              professionals in programming, website development, Business
              Management, Photography, and more.
            </p>
            <div class="hero_content-action d-flex flex-wrap">
              <a class="btn btn--gradient" href="https://bit.ly/starlabentryform" data-aos="fade-left">
                <span class="text">Register Now</span>
              </a>
              <a
                class="btn btn--highlight"
                href="./courses.php"
                data-aos="fade-left"
                data-aos-delay="50"
              >
                <span class="text">See Our Programs</span>
              </a>
            </div>
          </div>
          <div class="hero_media col-lg-6">
            <lottie-player
              src="lottie/hero.json"
              background="transparent"
              speed="1"
              style="width: 100%; height: 100%"
              loop
              autoplay
            ></lottie-player>
          </div>
        </div>
      </section>
      <!-- hero section end -->
      <!-- features section start -->
      <div class="features">
        <div class="container">
          <ul class="features_list d-md-flex flex-wrap">
            <li
              class="features_list-item col-md-4"
              data-order="1"
              data-aos="fade-up"
            >
              <div class="card">
                <div class="content">
                  <div class="card_media">
                    <i class="icon-globe-solid icon"></i>
                  </div>
                  <div class="card_main">
                    <h5 class="card_main-title">Global degree programs</h5>
                    <p class="card_main-text">
                      Get a degree after a successful educational or digital
                      program.
                    </p>
                  </div>
                </div>
              </div>
            </li>
            <li
              class="features_list-item col-md-4"
              data-order="2"
              data-aos="fade-up"
            >
              <div class="card">
                <div class="content">
                  <div class="card_media">
                    <i class="icon-headset-solid icon"></i>
                  </div>
                  <div class="card_main">
                    <h5 class="card_main-title">Live Hybrid lectures</h5>
                    <p class="card_main-text">
                      Enjoy quality lectures on-site and remotely from qualified
                      personnel.
                    </p>
                  </div>
                </div>
              </div>
            </li>
            <li
              class="features_list-item col-md-4"
              data-order="3"
              data-aos="fade-up"
            >
              <div class="card">
                <div class="content">
                  <div class="card_media">
                    <i class="icon-user-graduate-solid icon"></i>
                  </div>
                  <div class="card_main">
                    <h5 class="card_main-title">Get a certificate</h5>
                    <p class="card_main-text">
                      Enroll for your desired tech or academic related course to
                      earn a certificate.
                    </p>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <!-- features section end -->
      <!-- promo section start -->
      <section class="promo">
        <div
          class="container d-flex flex-column-reverse flex-lg-row justify-content-lg-end"
        >
          <div class="promo_media">
            <lottie-player
              src="lottie/scene.json"
              background="transparent"
              speed="1"
              style="width: 100%; height: 100%"
              loop
              autoplay
            ></lottie-player>
          </div>
          <div class="promo_content">
            <h2 class="promo_content-header" data-aos="fade-left">
              Learn and get a profession online
            </h2>
            <p
              class="promo_content-text"
              data-aos="fade-up"
              data-aos-delay="50"
            >
              Introduce yourself to a universe of talent building, skills
              acquisition, and academic development. Get in-depth exposure to
              classes, trainings, and workshops to help build your portfolio and
              professionalism.
            </p>
            <a
              class="promo_content-btn btn btn--gradient"
              href="https://bit.ly/starlabentryform"
              data-aos="fade-up"
              data-aos-delay="100"
            >
              <span class="text">Try for Free</span>
            </a>
          </div>
        </div>
      </section>
      <!-- promo section end -->
      <!-- about section start -->
      <section class="about">
        <div class="container">
          <div class="about_deco">
            <lottie-player
              src="lottie/wave.json"
              background="transparent"
              speed="1"
              style="width: 100%; height: 100%"
              loop
              autoplay
            ></lottie-player>
          </div>
          <div class="about_main">
            <div class="content">
              <h2 class="about_main-header" data-aos="fade-in">
                How does it work?
              </h2>
              <ul class="about_main-list">
                <li class="about_main-list_item" data-aos="fade-up">
                  <i class="icon-check icon"></i>
                  <div class="content">
                    <h5 class="title">4 on-line/off-line programs</h5>
                    <p class="text">
                      Apply for any of our EduTech programs. Join our innovative
                      learning team with experienced facilitators.
                    </p>
                  </div>
                </li>
                <li
                  class="about_main-list_item"
                  data-aos="fade-up"
                  data-aos-delay="50"
                >
                  <i class="icon-check icon"></i>
                  <div class="content">
                    <h5 class="title">Subscribe for a learning space</h5>
                    <p class="text">
                      Gain the privilege to access our exquisite on-site
                      learning space with the best learning experience.
                    </p>
                  </div>
                </li>
                <li
                  class="about_main-list_item"
                  data-aos="fade-up"
                  data-aos-delay="100"
                >
                  <i class="icon-check icon"></i>
                  <div class="content">
                    <h5 class="title">
                      After completing the training and projects, you will
                      receive your certificate and degree
                    </h5>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div class="about_review" data-aos="zoom-in">
            <div class="about_review-wrapper">
              <div class="media">
                <picture>
                  <source
                    data-srcset="img/profile-dp/Nice-Akao.jpeg"
                    srcset="img/profile-dp/Nice-Akao.jpeg"
                  />
                  <img
                    class="lazy"
                    data-src="img/profile-dp/Nice-Akao.jpeg"
                    src="img/profile-dp/Nice-Akao.jpeg"
                    alt="media"
                  />
                </picture>
              </div>
              <div class="main">
                <h5 class="main_name">Nice Akao</h5>
                <ul class="rating d-flex align-items-center">
                  <li class="rating_star">
                    <i class="icon-star icon"></i>
                  </li>
                  <li class="rating_star">
                    <i class="icon-star icon"></i>
                  </li>
                  <li class="rating_star">
                    <i class="icon-star icon"></i>
                  </li>
                  <li class="rating_star">
                    <i class="icon-star icon"></i>
                  </li>
                  <li class="rating_star">
                    <i class="icon-star icon"></i>
                  </li>
                </ul>
                <q class="main_review quote">
                  “My time at StarLab was transformative. The skills, knowledge,
                  and connections I gained have been vital to my career. I
                  highly recommend it to all creative enthusiasts.”
                </q>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- about section end -->
      <!-- popular courses section start -->
      <section class="popular">
        <div class="container">
          <div class="popular_header">
            <h2 class="popular_header-title" data-aos="fade-up">
              Popular courses
            </h2>
            <p class="popular_header-text" data-aos="fade-down">
              We offer four main programs entailing diverse trainings and
              courses to develop your talent and provide the educational
              qualification you desire.
            </p>
          </div>
          <!-- <ul
            class="popular_tags courses-tags d-flex flex-wrap align-items-center justify-content-center"
          >
            <li class="list-item" data-aos="fade-left">
              <a class="tag" href="#">programming</a>
            </li>
            <li class="list-item" data-aos="fade-left" data-aos-delay="50">
              <a class="tag" href="#">management</a>
            </li>
            <li class="list-item" data-aos="fade-left" data-aos-delay="100">
              <a class="tag" href="#">art</a>
            </li>
            <li class="list-item" data-aos="fade-left" data-aos-delay="150">
              <a class="tag" href="#">digital marketing</a>
            </li>
            <li class="list-item" data-aos="fade-left" data-aos-delay="200">
              <a class="tag" href="#">game development</a>
            </li>
            <li class="list-item" data-aos="fade-left" data-aos-delay="250">
              <a class="tag" href="#">smm</a>
            </li>
          </ul> -->
          <ul class="popular_list d-md-flex flex-wrap">
          <li
              class="popular_list-card course-card col-12 col-md-6 col-lg-4"
              data-aos="fade-up"
              data-aos-delay="100"
            >
              <div class="course-card_wrapper">
                <div class="top d-flex align-items-start">
                <span class="top_icon top_icon--blue">
                    <i class="icon-code-solid icon"></i>
                  </span>
                 
                  <div class="wrapper d-flex flex-column">
                    <h5 class="top_title">Computer Programming Basics</h5>
                    <ul class="rating d-flex align-items-center">
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                    </ul>
                    <span class="top_author">by StarLab Academy</span>
                    <span class="top_details">48 lectures ( 280 Hours)</span>
                  </div>
                </div>
                <!-- <div class="pricing">
                  <span class="pricing_price h5"
                    >$120 all course / $20 per month</span
                  >
                </div> -->
                <div class="bottom">
                  <ul class="bottom_list">
                    <li class="bottom_list-item d-flex align-items-start">
                      <i class="bottom_list-item_marker icon-circle"></i>
                      <p class="bottom_list-item_text">
                        Learn the fundamentals of web development
                      </p>
                    </li>
                    <li class="bottom_list-item d-flex align-items-start">
                      <i class="bottom_list-item_marker icon-circle"></i>
                      <p class="bottom_list-item_text">
                       Identify key steps neccesary to becoming a web developer including languages and Frameworks.
                      </p>
                    </li>
                  </ul>
                  <a class="bottom_btn btn btn--bordered btn--arrow" href="https://bit.ly/starlabentryform">
                    sign up for a course
                    <i class="icon-arrow-right-solid icon"></i>
                  </a>
                </div>
              </div>
            </li>
            <li
              class="popular_list-card course-card col-12 col-md-6 col-lg-4"
              data-aos="fade-up"
              data-aos-delay="50"
            >
              <div class="course-card_wrapper">
                <div class="top d-flex align-items-start">
                  <span class="top_icon top_icon--orange">
                    <i class="icon-css3 icon"></i>
                  </span>
                  <div class="wrapper d-flex flex-column">
                    <h5 class="top_title">Introduction to Design</h5>
                    <ul class="rating d-flex align-items-center">
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                    </ul>
                    <span class="top_author">by StarLab Academy</span>
                    <span class="top_details">48 lectures ( 280 Hours)</span>
                  </div>
                </div>
                <!-- <div class="pricing">
                  <span class="pricing_price h5"
                    >$120 all course / $20 per month</span
                  >
                </div> -->
                <div class="bottom">
                  <ul class="bottom_list">
                    <li class="bottom_list-item d-flex align-items-start">
                      <i class="bottom_list-item_marker icon-circle"></i>
                      <p class="bottom_list-item_text">
                      Learn the principles of Graphics design and UI/UX. 
                      </p>
                    </li>
                    <li class="bottom_list-item d-flex align-items-start">
                      <i class="bottom_list-item_marker icon-circle"></i>
                      <p class="bottom_list-item_text">
                        Learn the basics of all the branches of Design  and how to create appealing and engaging designs.
                      </p>
                    </li>
                  </ul>
                  <a class="bottom_btn btn btn--bordered btn--arrow" href="https://bit.ly/starlabentryform">
                    sign up for a course
                    <i class="icon-arrow-right-solid icon"></i>
                  </a>
                </div>
              </div>
            </li>
            <li
              class="popular_list-card course-card col-12 col-md-6 col-lg-4"
              data-aos="fade-up"
            >
              <div class="course-card_wrapper">
                <div class="top d-flex align-items-start">
                <span class="top_icon top_icon--sky">
                    <i class="icon-sitemap-solid icon"></i>
                  </span>
                  <div class="wrapper d-flex flex-column">
                    <h5 class="top_title">Content Management</h5>
                    <ul class="rating d-flex align-items-center">
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                      <li class="rating_star">
                        <i class="icon-star icon"></i>
                      </li>
                    </ul>
                    <span class="top_author">by StarLab Academy</span>
                    <span class="top_details">48 lectures ( 280 Hours)</span>
                  </div>
                </div>
                <!-- <div class="pricing">
                  <span class="pricing_price h5"
                    >$120 all course / $20 per month</span
                  >
                </div> -->
                <div class="bottom">
                  <ul class="bottom_list">
                    <li class="bottom_list-item d-flex align-items-start">
                      <i class="bottom_list-item_marker icon-circle"></i>
                      <p class="bottom_list-item_text">
                        Learn Search Engine Optimization (SEO)
                      </p>
                    </li>
                    <li class="bottom_list-item d-flex align-items-start">
                      <i class="bottom_list-item_marker icon-circle"></i>
                      <p class="bottom_list-item_text">
                       Learn how to Manage websites and social media pages in order to increase traffic to businesses.
                      </p>
                    </li>
                  </ul>
                  <a class="bottom_btn btn btn--bordered btn--arrow" href="https://bit.ly/starlabentryform">
                    sign up for a course
                    <i class="icon-arrow-right-solid icon"></i>
                  </a>
                </div>
              </div>
            </li>
            
          </ul>
          <a class="popular_btn btn btn--gradient" href="./courses.php">
            <span class="text">Learn more</span>
          </a>
        </div>
      </section>
      <!-- popular courses section end -->
      <!-- banner section start -->
      <div class="banner">
        <div class="underlay"></div>
        <div class="container d-lg-flex align-items-center">
          <div class="banner_content">
            <h4 class="banner_content-title" data-aos="fade-up">
              Unlimited access to educational materials and lectures for
              subscribers
            </h4>
            <div class="wrapper" data-aos="fade-up" data-aos-delay="50">
              <a class="banner_content-btn btn btn--gradient " href="./404.php"
                > <span class="text">
                See pricing plans
                </span></a
              >
            </div>
          </div>
          <!-- <div class="banner_media">
            <picture>
              <source
                data-srcset="./img/images (2).jpeg"
                srcset="./img/images (2).jpeg"
              />
              <img
                class="lazy"
                data-src="./img/images (2).jpeg"
                src="./img/images (2).jpeg"
                alt="media"
              />
            </picture>
          </div> -->
        </div>
      </div>
      <!-- banner section end -->
    </main>
    <!-- homepage content end -->
    <?php include 'footer.php'; ?>
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
    <script src="js/common.min.js"></script>
  </body>
</html>
